export const SERVICE_URL = 'http://192.168.3.4:8091/'

export const IFRAME_SRC_URL = 'ghgqgj.kjzbdev.com'

export const IFRAME_TAR_URL = '192.168.3.4:8091'
